var searchData=
[
  ['addcrc',['AddCRC',['../namespaceToolBox.html#a10e153078c33ad93f51e502cb9f7f05b',1,'ToolBox']]],
  ['addpacket',['addPacket',['../classSerialCommunicator.html#a8e4f1bde95d6314fb692b44081de882f',1,'SerialCommunicator']]]
];
