var searchData=
[
  ['numbytesrx',['NumBytesRx',['../classport__usb__functions_1_1port__usb.html#a0329f9276196fc58b64812324d096f22',1,'port_usb_functions::port_usb']]]
];
