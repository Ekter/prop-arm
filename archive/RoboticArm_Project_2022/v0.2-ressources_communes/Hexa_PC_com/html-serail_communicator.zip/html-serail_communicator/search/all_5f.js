var searchData=
[
  ['_5fft_5fdevice_5flist_5finfo_5fnode',['_ft_device_list_info_node',['../struct__ft__device__list__info__node.html',1,'']]],
  ['_5fftcomstat',['_FTCOMSTAT',['../struct__FTCOMSTAT.html',1,'']]],
  ['_5fftdcb',['_FTDCB',['../struct__FTDCB.html',1,'']]],
  ['_5ffttimeouts',['_FTTIMEOUTS',['../struct__FTTIMEOUTS.html',1,'']]],
  ['_5fwin32_5fwinnt',['_WIN32_WINNT',['../targetver_8h.html#ac50762666aa00bd3a4308158510f1748',1,'targetver.h']]]
];
