var searchData=
[
  ['number_5fdebug_5fdata',['NUMBER_DEBUG_DATA',['../namespaceserialComms.html#a9050242dcf56fd5bad4b375022ac19d3',1,'serialComms']]],
  ['numberofunknownpackets',['numberOfUnknownPackets',['../classSerialCommunicator.html#aaa52c93da93a1cd9fb8f40d362c97773',1,'SerialCommunicator']]],
  ['numbytesrx',['NumBytesRx',['../classport__usb__functions_1_1port__usb.html#a0329f9276196fc58b64812324d096f22',1,'port_usb_functions::port_usb']]]
];
