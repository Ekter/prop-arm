var searchData=
[
  ['open',['open',['../classport__com.html#a808cd81e5c09c64c1dffc21d4da11e7a',1,'port_com::open()'],['../classport__usb__functions_1_1port__usb.html#a3ba6d1e6a66e3b09f35d100e988eb778',1,'port_usb_functions::port_usb::open()']]]
];
