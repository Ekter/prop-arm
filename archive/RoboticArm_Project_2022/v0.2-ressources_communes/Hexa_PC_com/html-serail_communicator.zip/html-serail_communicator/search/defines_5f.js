var searchData=
[
  ['_5fwin32_5fwinnt',['_WIN32_WINNT',['../targetver_8h.html#ac50762666aa00bd3a4308158510f1748',1,'targetver.h']]]
];
