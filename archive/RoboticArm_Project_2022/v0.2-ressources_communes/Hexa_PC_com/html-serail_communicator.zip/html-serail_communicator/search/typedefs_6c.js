var searchData=
[
  ['lpftcomstat',['LPFTCOMSTAT',['../ftd2xx_8h.html#a1f5349d05f9219ca26b97e97fb345cb3',1,'ftd2xx.h']]],
  ['lpftdcb',['LPFTDCB',['../ftd2xx_8h.html#a2e9080fe9ecd5c2db204a24c5f169c4b',1,'ftd2xx.h']]],
  ['lpfttimeouts',['LPFTTIMEOUTS',['../ftd2xx_8h.html#a4cfbb43e220e1453c43e30278b7c3d6e',1,'ftd2xx.h']]]
];
