var searchData=
[
  ['xoffchar',['XoffChar',['../struct__FTDCB.html#a30a25a1c40525289b24b29f6593a6c51',1,'_FTDCB']]],
  ['xofflim',['XoffLim',['../struct__FTDCB.html#af78536d2734d9172b6707df1d3b1326d',1,'_FTDCB']]],
  ['xonchar',['XonChar',['../struct__FTDCB.html#aee3e405df31d5b168110814d5529b014',1,'_FTDCB']]],
  ['xonlim',['XonLim',['../struct__FTDCB.html#a44679a1dcfaa0f97bc4d1500538c4b47',1,'_FTDCB']]]
];
