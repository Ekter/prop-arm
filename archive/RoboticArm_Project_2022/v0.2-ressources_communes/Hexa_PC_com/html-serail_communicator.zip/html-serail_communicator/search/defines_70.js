var searchData=
[
  ['port_5fcom',['PORT_COM',['../serialCommunicator_8h.html#afa2b839dfaf9f60bb42d19c744cbd75f',1,'serialCommunicator.h']]],
  ['port_5fusb',['PORT_USB',['../serialCommunicator_8h.html#a48da1855a5b3c05e6100556ba5c7c658',1,'serialCommunicator.h']]]
];
