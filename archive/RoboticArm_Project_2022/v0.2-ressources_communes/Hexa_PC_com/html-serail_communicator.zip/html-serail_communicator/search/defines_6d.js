var searchData=
[
  ['min',['MIN',['../port__usb__functions_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f',1,'port_usb_functions.h']]]
];
