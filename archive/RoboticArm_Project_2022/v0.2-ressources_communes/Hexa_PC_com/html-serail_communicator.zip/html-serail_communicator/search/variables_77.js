var searchData=
[
  ['wreserved',['wReserved',['../struct__FTDCB.html#a09597c9223026be01c71a1374715fb2f',1,'_FTDCB']]],
  ['wreserved1',['wReserved1',['../struct__FTDCB.html#a6775b20a593cc63edde243ed9605a028',1,'_FTDCB']]],
  ['writetotaltimeoutconstant',['WriteTotalTimeoutConstant',['../struct__FTTIMEOUTS.html#ac36dfafaf9522e0b041080242538d196',1,'_FTTIMEOUTS']]],
  ['writetotaltimeoutmultiplier',['WriteTotalTimeoutMultiplier',['../struct__FTTIMEOUTS.html#a1944986d4b6760a45db8ce1b58fa3688',1,'_FTTIMEOUTS']]]
];
