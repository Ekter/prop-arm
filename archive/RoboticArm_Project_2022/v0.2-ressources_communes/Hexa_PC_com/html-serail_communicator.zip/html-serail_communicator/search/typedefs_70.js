var searchData=
[
  ['pft_5fevent_5fhandler',['PFT_EVENT_HANDLER',['../ftd2xx_8h.html#a6a910f39c71ed4d8eab22156b575e3b5',1,'ftd2xx.h']]],
  ['pft_5fprogram_5fdata',['PFT_PROGRAM_DATA',['../ftd2xx_8h.html#acbebd7f5804c142d322cd81d2a77d755',1,'ftd2xx.h']]]
];
