var searchData=
[
  ['m_5fhidcomdev',['m_hIDComDev',['../classport__com.html#ac5fc20996f9a5b60bff8756a40260a11',1,'port_com']]],
  ['m_5foverlappedread',['m_OverlappedRead',['../classport__com.html#a0c8a7a5ae80bb9ebc27a64fd214f46db',1,'port_com']]],
  ['m_5foverlappedwrite',['m_OverlappedWrite',['../classport__com.html#a2f8e721786466a0a1034a180e660cdf9',1,'port_com']]],
  ['makepacket',['makePacket',['../classSerialCommunicator.html#a32259d59c0731af958945a34cc223f69',1,'SerialCommunicator']]],
  ['manufacturer',['Manufacturer',['../structft__program__data.html#ae65c66ae3c75ac56bb460454f115da9d',1,'ft_program_data']]],
  ['manufacturerid',['ManufacturerId',['../structft__program__data.html#a06baa3f17985f533b165c121ec42b607',1,'ft_program_data']]],
  ['maxpower',['MaxPower',['../structft__program__data.html#a95bf98d9c0b056d68078bc2d2f66b20e',1,'ft_program_data']]],
  ['message_5ferror',['message_error',['../classSerialCommunicator.html#a1bef31c40132d7b460ea12d6dfbcefbd',1,'SerialCommunicator']]],
  ['min',['MIN',['../port__usb__functions_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f',1,'port_usb_functions.h']]],
  ['my_5fport_5fcom',['my_port_com',['../classSerialCommunicator.html#aec4ec9c22ebb5dc5ebe60ac17b865bca',1,'SerialCommunicator']]],
  ['my_5fport_5fusb',['my_port_usb',['../classSerialCommunicator.html#a5e3c53ac7cec38d28cdd70c69d5810c2',1,'SerialCommunicator']]]
];
